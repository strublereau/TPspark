package com.sparkProject

import org.apache.spark.sql.{SQLContext, SparkSession}

object Job {

  def main(args: Array[String]): Unit = {

    // SparkSession configuration
    val spark = SparkSession
      .builder
      .master("local")
      .appName("spark session TP_parisTech")
      .getOrCreate()

    val sc = spark.sparkContext

    import spark.implicits._


    /** ******************************************************************************
      *
      * TP 1
      *
      *        - Set environment, InteliJ, submit jobs to Spark
      *        - Load local unstructured data
      *        - Word count , Map Reduce
      * *******************************************************************************/


    // ----------------- word count ------------------------

    val df_wordCount = sc.textFile("/Users/stephanetrublereau/spark/spark-2.0.0-bin-hadoop2.7/README.md")
      .flatMap { case (line: String) => line.split(" ") }
      .map { case (word: String) => (word, 1) }
      .reduceByKey { case (i: Int, j: Int) => i + j }
      .toDF("word", "count")

    df_wordCount.orderBy($"count".desc).show()


    /** ******************************************************************************
      *
      * TP 2 : début du projet
      *
      * *******************************************************************************/
    val df_cumulative = spark
      .read

      .option("comment", "#")
      .option("header", true)
      .option("inferSchema ", true)
      .csv("/Users/stephanetrublereau/spark/spark-2.0.0-bin-hadoop2.7/cumulative.csv")

    //df_cumulative.show()

    println("nombre de ligne : ", df_cumulative.count())
    println("nombre de colonnes : ", df_cumulative.columns.length)

    // df_cc = df_cumulative.columns.slice(10, 20)

    import org.apache.spark.sql.functions._

    val c = df_cumulative.columns.slice(from = 10, until = 20).toList

    val ndf = df_cumulative.select(c.map(col): _*)
    ndf.show()
    //afficher le schema
    df_cumulative.printSchema()

    //3.F on compte en regroupant par koi_disposition
    df_cumulative.groupBy("koi_disposition").count().show()

    //
    // 4.A
    //df_filter
    val df_filter = df_cumulative.filter(not($"koi_disposition" === "CANDIDATE"))

    //df_filter.show()

    println("nombre de ligne : ", df_filter.count())
    println("nombre de colonnes : ", df_filter.columns.length)
    //
    //on compte les éléments disctinct de koi_eccen_err1
    //
    df_filter.groupBy("koi_eccen_err1").count().orderBy($"count".desc).show()
    val df_drop_cols = df_filter.drop("koi_eccen_err1")
    println("nombre de ligne : ", df_drop_cols.count())
    println("nombre de colonnes : ", df_drop_cols.columns.length)
    //
    // On drop l'ensemble des colonnes listées
    //
    val df_drop_all_cols = df_drop_cols.drop("index", "kepid", "koi_fpflag_nt",
      "koi_fpflag_nt", "koi_fpflag_nt", "koi_fpflag_nt", "koi_fpflag_nt",
      "koi_fpflag_ss", "koi_fpflag_co", "koi_fpflag_co",
      "koi_fpflag_ec", "koi_sparprov", "koi_trans_mod",
      "koi_datalink_dvr", "koi_datalink_dvs", "koi_datalink_dvs",
      "koi_tce_delivname", "koi_parm_prov", "koi_limbdark_mod",
      "koi_fittype", "koi_disp_prov", "koi_comment", "kepoi_name",
      "kepler_name", "koi_vet_date", "koi_pdisposition")
    println("nombre de lignes  drop all columns: ", df_drop_all_cols.count())
    println("nombre de colonnes : ", df_drop_all_cols.columns.length)
    //afficher le schema
    df_drop_all_cols.printSchema()
    val colonnes = df_drop_all_cols.columns
    var listCols_drop  = List[String]()
    for (a <- colonnes) {
      println("Value of colonne : " + a)
      if (df_drop_all_cols.groupBy(a).count().count() < 2) {
        println("A supprimer" + a);
        listCols_drop ++= List(a)
      }
    }
    println("nombre de colonne à supprimer : " )
    println(listCols_drop.size)
    println("Dropped columns: ")
    val df_net = df_drop_all_cols.drop(listCols_drop: _*)
    println("nombre de lignes  drop all columns: ", df_net.count())
    println("nombre de colonnes : ", df_net.columns.length)
    // Affichage des statistiques pour les 10 premieres colonnes
    df_net.describe(df_net.columns.slice(0,10):_*).show()

    // Computing basic statistics (including the mean) on the numerical columns
    val df_stats = df_net.describe()
    println(df_stats)
    // List of the numerical columns
    val statCols = df_stats.columns
    println(statCols)

    // Show the statistics of the 10 first numerical columns
    //df_stats.select(statCols.slice(0, 10).map(col): _*).show()

    //val df_filled = df_net.na.fill(0.0)
    val df4 = df_net.na.fill(0.0)
    // A retravailler 5
    val df_labels = df4.select("rowid", "koi_disposition")
    val df_features = df4.drop("koi_disposition")
    // 5.A Join on the column rowid
    val df_treated = df_features
      .join(df_labels, usingColumn = "rowid")


    // 6
    def udf_sum = udf((col1: Double, col2: Double) => col1 + col2)


    val df_newFeatures = df_treated
      .withColumn("koi_ror_min", udf_sum($"koi_ror", $"koi_ror_err2"))
      .withColumn("koi_ror_max", $"koi_ror" + $"koi_ror_err1")

    // 7/
    //df.write.format("com.databricks.spark.csv").save(wd + "/data/")
    df_newFeatures.coalesce(1) // optional : regroup all data in ONE partition, so that results are printed in ONE file
      // >>>> You should not that in general, only when the data are small enough to fit in the memory of a single machine.
      .write
      .mode("overwrite")
      .option("header", "true")
      .csv("/Users/stephanetrublereau/documents/tp_spark/cleanedDataFrame.csv")
  }
}
